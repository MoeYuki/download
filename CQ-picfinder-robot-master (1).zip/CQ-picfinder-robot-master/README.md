# CQ-picfinder-robot

这是一个以 Nodejs 编写的酷Q机器人插件，用于搜图、搜番、搜本子，并夹带了许多娱乐向功能（。）

目前支持：

- [saucenao](https://saucenao.com)
- [WhatAnime](https://trace.moe)
- [ascii2d](https://ascii2d.net)

附加功能：

- 复读
- setu
- OCR
- 明日方舟公开招募计算
- 定时提醒

详细说明请移步 [Wiki](../../wiki)

## TODO

重构为更加模块化的一个机器人框架，以支持自定义插件
