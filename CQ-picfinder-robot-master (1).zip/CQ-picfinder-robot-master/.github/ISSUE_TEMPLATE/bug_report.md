---
name: 问题汇报
about: 出 bug 啦
title: ''
labels: ''
assignees: ''

---

**描述这个 bug**
rt

**如何复现**
复现步骤（如果能复现）
1. 去 xxx
2. 点击 xxx
3. 输入 xxx
4. 出现 bug

**期望现象**
如果没 bug，本来应该得到什么结果

**截图及日志**
- 问题相关截图
- 日志内容（复制粘贴或截图，复制粘贴请包裹在代码块中）

**平台**
 - 操作系统：例如 Windows 10 / Ubuntu 16.04 / CentOS 7 
 - Node 版本：x.x.x

**附加内容**
先生，还有什么要补充的吗
